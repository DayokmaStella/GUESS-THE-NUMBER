package com.example.guess;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int randomNumber;
    private EditText guessEditText;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        guessEditText = findViewById(R.id.guessEditText);
        resultTextView = findViewById(R.id.resultTextView);

        Button guessButton = findViewById(R.id.guessButton);
        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkGuess();
            }
        });

        generateRandomNumber();
    }

    private void generateRandomNumber() {
        Random random = new Random();
        randomNumber = random.nextInt(100) + 1; // Generate a random number between 1 and 100
    }

    private void checkGuess() {
        String guessString = guessEditText.getText().toString();

        if (!guessString.isEmpty()) {
            int userGuess = Integer.parseInt(guessString);

            if (userGuess == randomNumber) {
                showResult("Congratulations! You guessed the number.");
                generateRandomNumber(); // Generate a new random number for the next round
            } else if (userGuess < randomNumber) {
                showResult("Too low! Try again.");
            } else {
                showResult("Too high! Try again.");
            }
        } else {
            showResult("Please enter a guess.");
        }
    }

    private void showResult(String message) {
        resultTextView.setText(message);
    }
}