package com.example.guess;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GuessTheNum extends AppCompatActivity {
    public Button buttons;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guess_the_num);
        buttons = findViewById(R.id.buttonPlay);
        buttons.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(GuessTheNum.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
